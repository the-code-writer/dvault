/* eslint-disable */
type SolanaConnectionButtonT = {
    foo: boolean;
  };
  
  interface ISolanaConnectionButton {
    inline?:  boolean;
    children?: React.ReactNode;
  }
  
  export type { SolanaConnectionButtonT, ISolanaConnectionButton };
  