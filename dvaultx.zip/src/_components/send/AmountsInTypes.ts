/* eslint-disable */
type AmountsInT = {
  foo: boolean;
};

interface IAmountsIn {
  onAmountsIn: any;
  children?: React.ReactNode;
}

export type { AmountsInT, IAmountsIn };
