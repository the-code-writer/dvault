/* eslint-disable */ 
type RecipientWalletAddressT = {
    foo: boolean;
}

interface IRecipientWalletAddress {
    onRecipientWalletAddress?: any;
    children?: React.ReactNode;
};

export type { RecipientWalletAddressT, IRecipientWalletAddress };