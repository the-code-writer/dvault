/* eslint-disable */
type UnlockCriteriaT = {
  foo: boolean;
};

interface IUnlockCriteria {
  onUnlockCriteriaFormData: any;
  children?: React.ReactNode;
}

export type { UnlockCriteriaT, IUnlockCriteria };
