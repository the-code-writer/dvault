/* eslint-disable */
type TotalFeesT = {
  foo: boolean;
};

interface ITotalFees {
  onTotalFees: any;
  amountsInValue: number;
  children?: React.ReactNode;
}

export type { TotalFeesT, ITotalFees };
