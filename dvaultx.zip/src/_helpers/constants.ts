/* eslint-disable */
export const ZERO_ADDRESS = import.meta.env.VITE_APP_API_BASE_URL;

export const ZERO_HASH = import.meta.env.VITE_APP_API_BASE_URL;

export const PROTOCOL = import.meta.env.VITE_APP_PROTOCOL;

export const SITE_NAME = import.meta.env.VITE_APP_SITE_NAME;

export const LTR = import.meta.env.VITE_APP_LTR;

export const RTL = import.meta.env.VITE_APP_RTL;

export const DEFAULT_DIRECTION = import.meta.env.VITE_APP_DEFAULT_DIRECTION;

export const DEFAULT_SEPERATOR = import.meta.env.VITE_APP_DEFAULT_SEPERATOR;

export const DEFAULT_LOCALE = import.meta.env.VITE_APP_DEFAULT_LOCALE;

export const LOCALES = import.meta.env.VITE_APP_LOCALES;

export const DEFAULT_TYPE = import.meta.env.VITE_APP_DEFAULT_TYPE;

export const DEFAULT_TITLE = import.meta.env.VITE_APP_DEFAULT_TITLE;

export const DEFAULT_DESCRIPTION = import.meta.env.VITE_APP_DEFAULT_DESCRIPTION;

export const DEFAULT_KEYWORDS = import.meta.env.VITE_APP_DEFAULT_KEYWORDS;

export const DEFAULT_AUTHOR = import.meta.env.VITE_APP_DEFAULT_AUTHOR;

export const DEFAULT_THUMBNAIL = import.meta.env.VITE_APP_DEFAULT_THUMBNAIL;

export const DEFAULT_CARD = import.meta.env.VITE_APP_DEFAULT_CARD;

export const THEME_COLOR = import.meta.env.VITE_APP_THEME_COLOR;

export const TWITTER_USERNAME = import.meta.env.VITE_APP_TWITTER_USERNAME;

export const TWITTER_AUTHOR = import.meta.env.VITE_APP_TWITTER_AUTHOR;

export const FAVICONS = import.meta.env.VITE_APP_FAVICONS;

export const STYLES = import.meta.env.VITE_APP_STYLES;

export const API_BASE_URL = import.meta.env.VITE_APP_API_BASE_URL;
