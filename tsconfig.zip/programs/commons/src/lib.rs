use anchor_lang::prelude::*;

use getrandom::getrandom;
use uuid::Uuid;
use crate::libs::cryptolib::hash_256;

declare_id!("J2q2ki2AuY3E3T5t7nyLB4vopSk7oUTUk6RuAZVYZeGc");

#[program]
pub mod commons { }

use std::fmt;

pub enum SysError {
    VaultTrackerAccountAlreadyExists(String),
    VaultAccountAlreadyExists(String),
    VaultAccountHasExistingUsers(String, u64),
    VaultAccountHasExistingTransactions(String, u64),
    VaultAccountHasExistingTokens(String, u64),
    UserAccountAlreadyExists,
    UserAccountHasExistingTransactions(String, u64),
    TransactionAccountAlreadyExists,
    TransactionAccountHasExistingTransactionItems(String, u64),
    TransactionItemAccountPayloadMissing,
    EmptyPassword,
    ShortPassword,
    LongPassword,
    EmptyName,
    LongName,
    EmptyDescription,
    LongDescription,
    InvalidNumberOfAccounts,
    InvalidInput(String),
    InvalidAmount(u64),
    InvalidPublicKey(String),
    InvalidProgramID(String, String),
    InvalidAuthority(String, String),
    InsufficientFunds(String, u64),
    InsufficientFundsRental(String, u64, u64),
    TokenAccountTokens(String, u64),
    TransactionItemDepositError(String),
    TransactionItemSendError(String),
    TransactionItemTransferError(String),
    TransactionItemClaimError(String),
    TransactionItemWithdrawalError(String),
    TransactionItemStatementError(String),
}

impl fmt::Display for SysError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            SysError::VaultTrackerAccountAlreadyExists(ref public_key) => write!(f, "The vault tracker account for this signer wallet has already been initialized with the public key: {}", public_key),
            SysError::VaultAccountAlreadyExists(ref public_key) => write!(f, "The vault account for this vault tracker has already been initialized with the public key: {}", public_key),
            SysError::VaultAccountHasExistingUsers(ref account, count) => write!(f, "Vault Account '{}' has {} existing users.", account, count),
            SysError::VaultAccountHasExistingTransactions(ref account, count) => write!(f, "Vault Account '{}' has {} existing transactions.", account, count),
            SysError::VaultAccountHasExistingTokens(ref account, count) => write!(f, "Vault Account '{}' has {} existing token accounts.", account, count),
            SysError::UserAccountAlreadyExists => write!(f, "The user account for this vault has already been initialized"),
            SysError::UserAccountHasExistingTransactions(ref account, count) => write!(f, "User Account '{}' has {} existing transactions.", account, count),
            SysError::TransactionAccountAlreadyExists => write!(f, "The transaction account for this vault has already been initialized"),
            SysError::TransactionAccountHasExistingTransactionItems(ref account, count) => write!(f, "Transaction Account '{}' has {} existing transaction items.", account, count),
            SysError::TransactionItemAccountPayloadMissing => write!(f, "Transaction payload is missing"),
            SysError::EmptyPassword => write!(f, "Password cannot be an empty string"),
            SysError::ShortPassword => write!(f, "Password cannot be less than 4 characters"),
            SysError::LongPassword => write!(f, "Password cannot exceed 16 characters"),
            SysError::EmptyName => write!(f, "Name cannot be an empty string"),
            SysError::LongName => write!(f, "Name cannot exceed 16 characters"),
            SysError::EmptyDescription => write!(f, "Description cannot be an empty string"),
            SysError::LongDescription => write!(f, "Description cannot exceed 64 characters"),
            SysError::InvalidNumberOfAccounts => write!(f, "Invalid number of accounts"),
            SysError::InvalidInput(ref amount) => write!(f, "Invalid input: {}", amount),
            SysError::InvalidAmount(ref u8) => write!(f, "Invalid amount: {}", u8),
            SysError::InvalidPublicKey(ref public_key) => write!(f, "Invalid public key: {}", public_key),
            SysError::InvalidProgramID(ref account, program_id) => write!(f, "Invalid Program ID: {}, required id: {}", program_id, account),
            SysError::InvalidAuthority(ref account, authority) => write!(f, "Invalid Authority: {}, required authority: {}", authority, account),
            SysError::InsufficientFunds(ref account, balance) => write!(f, "Account '{}' has insufficient funds. Lamport balance: {}", account, balance),
            SysError::InsufficientFundsRental(ref account, required, available) => write!(f, "Account '{}' has insufficient funds to pay for the rental. Required rental lamports: {}. Available lamports: {}", account, required, available),
            SysError::TokenAccountTokens(ref account, count) => write!(f, "Token Account '{}' has {} existing tokens.", account, count),
            SysError::TransactionItemDepositError(ref error) => write!(f, "Confidential Token deposit error: {}.", error),
            SysError::TransactionItemSendError(ref error) => write!(f, "Confidential Token send error: {}.", error),
            SysError::TransactionItemTransferError(ref error) => write!(f, "Confidential Token transfer error: {}.", error),
            SysError::TransactionItemClaimError(ref error) => write!(f, "Confidential Token claim error: {}.", error),
            SysError::TransactionItemWithdrawalError(ref error) => write!(f, "Confidential Token withdrawal error: {}.", error),
            SysError::TransactionItemStatementError(ref error) => write!(f, "Confidential Token statement error: {}.", error),
        }
    }
}

pub enum ErrorType {
    VaultError,
    UserError,
    TransactionError,
    TransactionItemError,
    DepositError,
    TransferError,
    SendError,
    ClaimError,
    WithdrawalError,
    StatementError,
    GenericError,
    UnspecifiedError,
}

impl ErrorType {
    const VAULT_ERROR: &'static str = "VaultError";
    const USER_ERROR: &'static str = "UserError";
    const TRANSACTION_ERROR: &'static str = "TransactionError";
    const TRANSACTION_ITEM_ERROR: &'static str = "TransactionItemError";
    const DEPOSIT_ERROR: &'static str = "DepositError";
    const TRANSFER_ERROR: &'static str = "TransferError";
    const SEND_ERROR: &'static str = "SendError";
    const CLAIM_ERROR: &'static str = "ClaimError";
    const WITHDRAWAL_ERROR: &'static str = "WithdrawalError";
    const STATEMENT_ERROR: &'static str = "StatementError";
    const GENERIC_ERROR: &'static str = "GenericError";
    const UNSPECIFIED_ERROR: &'static str = "UnspecifiedError";
}

pub fn throw_err(err_type: ErrorType, err_message: SysError) {
    match err_type {
        ErrorType::VaultError => panic!("{}: {}", ErrorType::VAULT_ERROR, err_message),
        ErrorType::UserError => panic!("{}: {}", ErrorType::USER_ERROR, err_message),
        ErrorType::TransactionError => {
            panic!("{}: {}", ErrorType::TRANSACTION_ERROR, err_message)
        }
        ErrorType::TransactionItemError => {
            panic!("{}: {}", ErrorType::TRANSACTION_ITEM_ERROR, err_message)
        }
        ErrorType::DepositError => panic!("{}: {}", ErrorType::DEPOSIT_ERROR, err_message),
        ErrorType::TransferError => panic!("{}: {}", ErrorType::TRANSFER_ERROR, err_message),
        ErrorType::SendError => panic!("{}: {}", ErrorType::SEND_ERROR, err_message),
        ErrorType::ClaimError => panic!("{}: {}", ErrorType::CLAIM_ERROR, err_message),
        ErrorType::WithdrawalError => panic!("{}: {}", ErrorType::WITHDRAWAL_ERROR, err_message),
        ErrorType::StatementError => panic!("{}: {}", ErrorType::STATEMENT_ERROR, err_message),
        ErrorType::GenericError => panic!("{}: {}", ErrorType::GENERIC_ERROR, err_message),
        _ => panic!("{}: {}", ErrorType::UNSPECIFIED_ERROR, err_message),
    }
}

pub const UPPERCASE: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
pub const LOWERCASE: &str = "abcdefghijklmnopqrstuvwxyz";
pub const NUMBERS: &str   = "0123456789";
pub const SYMBOLS: &str   = ")(*&^%$#@!~*/+?.";
 
pub fn gen_usr(username_length: usize) -> String {
    let mut username = String::new();
    for _ in 0..username_length {
        let mut buf = [0u8; 1];
        getrandom::getrandom(&mut buf).unwrap();
        username.push(char::from(buf[0] as char));
    }
    username
}

pub fn gen_pwd(password_length: usize) -> String {
    let mut password = String::new();
    for _ in 0..password_length {
        let mut buf = [0u8; 1];
        getrandom::getrandom(&mut buf).unwrap();
        password.push(char::from(buf[0] as char));
    }
    password
}

#[no_mangle]
pub fn gen_key() -> String {
    hash_256(format!("{}{}", gen_pwd(32), gen_uuid()));
}

#[no_mangle]
pub fn gen_uuid() -> String {
    let uuid: Uuid = Uuid::new_v4();
    uuid.to_string()
}
